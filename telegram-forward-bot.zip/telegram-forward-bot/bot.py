import os
import asyncio
from telegram import Update
from telegram.ext import ApplicationBuilder, ContextTypes, MessageHandler, filters, CommandHandler

# Configuration: BOT_TOKEN and OWNER_CHAT_ID can be provided via environment variables,
# or via config.json in the project folder with keys "bot_token" and "owner_chat_id".
def load_config():
    cfg = {}
    # try env first
    cfg['bot_token'] = os.environ.get('BOT_TOKEN')
    cfg['owner_chat_id'] = os.environ.get('OWNER_CHAT_ID')
    # fallback to config.json
    if (not cfg['bot_token'] or not cfg['owner_chat_id']) and os.path.exists('config.json'):
        try:
            with open('config.json','r',encoding='utf-8') as f:
                data = json.load(f)
                cfg['bot_token'] = cfg['bot_token'] or data.get('bot_token')
                cfg['owner_chat_id'] = cfg['owner_chat_id'] or str(data.get('owner_chat_id'))
        except Exception as e:
            print('Failed to read config.json:', e)
    if not cfg['bot_token'] or not cfg['owner_chat_id']:
        raise RuntimeError('BOT_TOKEN and OWNER_CHAT_ID must be provided via environment variables or config.json')
    # owner_chat_id should be int
    try:
        cfg['owner_chat_id'] = int(cfg['owner_chat_id'])
    except:
        raise RuntimeError('OWNER_CHAT_ID must be an integer chat id')
    return cfg

import json

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Привіт! Я пересилач повідомлень. Ваші повідомлення будуть переслані власнику бота.")

async def forward_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    cfg = context.bot_data.get('cfg')
    owner = cfg['owner_chat_id']
    sender = update.effective_user
    sender_name = sender.full_name if sender else "Unknown"
    sender_username = f"@{sender.username}" if sender and sender.username else ""
    header = f"Нове повідомлення від {sender_name} {sender_username}\nuser_id: {sender.id if sender else 'unknown'}\n----\n"
    try:
        msg = update.message
        # If it's a text message, send as text with header
        if msg.text:
            await context.bot.send_message(chat_id=owner, text=header + msg.text)
        else:
            # For media and other types, try forwarding the original message (keeps sender info hidden),
            # and send a header separately.
            await context.bot.send_message(chat_id=owner, text=header + "(медіа або інше повідомлення — переслано оригіналом)")
            await context.bot.forward_message(chat_id=owner, from_chat_id=msg.chat_id, message_id=msg.message_id)
    except Exception as e:
        print('Error forwarding message:', e)
        try:
            await context.bot.send_message(chat_id=owner, text=f"Не вдалося переслати повідомлення: {e}")
        except:
            pass

def main():
    cfg = load_config()
    app = ApplicationBuilder().token(cfg['bot_token']).build()
    # store config in bot_data for access in handlers
    app.bot_data['cfg'] = cfg

    app.add_handler(CommandHandler('start', start))
    # handle all messages (text, media, etc.)
    app.add_handler(MessageHandler(filters.ALL & (~filters.StatusUpdate.ALL), forward_message))

    print("Running bot...")
    app.run_polling()

if __name__ == '__main__':
    main()
